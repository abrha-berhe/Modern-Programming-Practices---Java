package Lab7_4;

public class RedheadDuck extends Duck {
	
	@Override
	public void display() { // implementing display method of Duck
		System.out.println("Displaying");

	}

}
