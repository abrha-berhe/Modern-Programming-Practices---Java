package Lab7_2;

public interface ClosedCurve {
	
	public double computePerimeter();
}
