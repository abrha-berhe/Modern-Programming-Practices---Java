package Lab9_10A;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
