package Lab1_ProjectManagment;

public class Feature {
	private Integer featureID;
	private String name;
	private double effort;

}
