package Lab1_ProjectManagment;

import java.util.*;

import java.time.LocalDate;

public class Sprint {
	private Integer SprintID;
	private LocalDate dueDate;
	private List<Feature> releaseFeatures;
}
