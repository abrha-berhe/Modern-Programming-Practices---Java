package Lab1_ProjectManagment;

import java.time.LocalDate;

public class Employee {
	private String name;
	private LocalDate dateOfBirth ;
	private String gender;
	private Address address;	

}
