package Lab1_ProjectManagment;

import java.util.*;

public class Project {
	private Integer projectId;
	private Integer projectName;
	private ProductBackLog productBackLog;
	private List<Release> releases;
 

}
