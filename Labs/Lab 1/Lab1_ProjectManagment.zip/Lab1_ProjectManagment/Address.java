package Lab1_ProjectManagment;

public class Address {
	private Integer addressID;
	private String phone;
	private String email;
	private String street;
	private String city;
	private String state;
	private String zipCode;	

}
