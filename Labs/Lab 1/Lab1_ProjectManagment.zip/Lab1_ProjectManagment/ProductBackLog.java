package Lab1_ProjectManagment;

import java.util.*;

public class ProductBackLog {
private Integer backLogID;
private String name;
private List<Feature> features;
}
