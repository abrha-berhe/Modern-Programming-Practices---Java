package Lab1_ProjectManagment;

import java.util.*;

public class ProjectManager {
	private Project project;
	private List<Developer> developers;
}
