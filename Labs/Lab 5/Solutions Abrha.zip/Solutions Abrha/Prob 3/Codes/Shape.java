package Lab5_3;

public interface Shape {
	double computeArea();
}
