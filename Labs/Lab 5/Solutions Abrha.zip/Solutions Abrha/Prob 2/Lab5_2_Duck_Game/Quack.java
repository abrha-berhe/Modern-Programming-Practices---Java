package Lab5_2_Duck_Game;

public class Quack implements QuackBehavior {

	@Override
	public void quack() {
		System.out.println("Standard quack...");

	}


}
