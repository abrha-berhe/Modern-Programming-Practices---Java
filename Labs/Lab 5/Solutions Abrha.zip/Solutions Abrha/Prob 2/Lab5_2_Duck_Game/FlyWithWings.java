package Lab5_2_Duck_Game;

public class FlyWithWings implements FlyBehavior {

	@Override
	public void fly() {
		System.out.println("Flies with Wings ...");
	}

}
