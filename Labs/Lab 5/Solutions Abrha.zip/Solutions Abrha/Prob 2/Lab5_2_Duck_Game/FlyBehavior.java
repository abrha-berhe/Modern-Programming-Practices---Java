package Lab5_2_Duck_Game;

public interface FlyBehavior {
	void fly();
}
