package Lab5_2_Duck_Game;

public interface QuackBehavior {
	
	void quack();

}
