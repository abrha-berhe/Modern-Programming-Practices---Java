package Lab3_Prob4;

public abstract class Property {
abstract public double computeRent();
}
