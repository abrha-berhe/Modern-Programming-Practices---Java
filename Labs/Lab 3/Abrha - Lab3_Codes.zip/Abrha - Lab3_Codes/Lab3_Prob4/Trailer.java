package Lab3_Prob4;

public class Trailer extends Property{
	Address address;
	Trailer(){
		
	}
 public double computeRent() {
		return 500;
	}
}
