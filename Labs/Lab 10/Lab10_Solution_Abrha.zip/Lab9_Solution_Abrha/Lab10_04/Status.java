package Lab10_04;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
