package Lab10_04;

public enum Gender{
	M, F
}
